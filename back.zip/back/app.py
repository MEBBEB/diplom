"""
backend/app.py
Flask API для футбольного предиктора
"""

import sys
import os
import psycopg2
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS

# Добавляем родительскую папку в путь для импорта predictor
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from predictor import FootballPredictor

app = Flask(__name__)
CORS(app)  # Разрешаем запросы с React

# Настройки БД
DB_SETTINGS = {
    'database': 'football_stats',
    'user': 'postgres',
    'password': 'Goyda_man1',
    'host': 'localhost',
    'port': '5432'
}

# Инициализируем предсказатель
print("Загрузка модели...")
predictor = FootballPredictor()
predictor.load_stats()
predictor._load_h2h_statistics()
predictor._load_league_stats()

if not predictor.load_model():
    print("Ошибка: модель не загружена!")
    exit(1)

print(f"Модель загружена (точность: {predictor.best_accuracy*100:.1f}%)")

# ============= ЭНДПОИНТЫ =============

@app.route('/api/teams', methods=['GET'])
def get_teams():
    """Получить список команд по лиге"""
    league_code = request.args.get('league_code', 'E0')
    
    conn = psycopg2.connect(**DB_SETTINGS)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT DISTINCT t.team_id, t.team_name
        FROM teams t
        JOIN matches m ON t.team_id IN (m.home_team_id, m.away_team_id)
        JOIN leagues l ON m.league_id = l.league_id
        WHERE l.league_code = %s
        ORDER BY t.team_name
    """, (league_code,))
    teams = [{'id': row[0], 'name': row[1]} for row in cursor.fetchall()]
    conn.close()
    return jsonify(teams)


@app.route('/api/team_stats/<int:team_id>', methods=['GET'])
def get_team_stats(team_id):
    """Получить статистику команды за всю историю"""
    stats = predictor.classical_stats.get(team_id, {})
    return jsonify({
        'home_wins': stats.get('home_wins', 0),
        'away_wins': stats.get('away_wins', 0),
        'home_win_rate': round(stats.get('home_win_rate', 0) * 100, 1),
        'away_win_rate': round(stats.get('away_win_rate', 0) * 100, 1),
        'avg_goals_scored': round(stats.get('avg_scored_per_game', 0), 2),
        'avg_goals_conceded': round(stats.get('avg_conceded_per_game', 0), 2),
        'goal_diff': stats.get('total_goal_diff', 0)
    })


@app.route('/api/team_stats_current_season/<int:team_id>', methods=['GET'])
def get_team_stats_current_season(team_id):
    """Получить статистику команды за текущий сезон (2025-2026)"""
    conn = psycopg2.connect(**DB_SETTINGS)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT 
            COUNT(CASE WHEN home_team_id = %s THEN 1 END) as home_matches,
            COUNT(CASE WHEN home_team_id = %s AND ftr = 'H' THEN 1 END) as home_wins,
            COALESCE(AVG(CASE WHEN home_team_id = %s THEN fthg END), 0) as avg_home_scored,
            COALESCE(AVG(CASE WHEN home_team_id = %s THEN ftag END), 0) as avg_home_conceded,
            COALESCE(SUM(CASE WHEN home_team_id = %s THEN fthg - ftag END), 0) as home_goal_diff,
            COUNT(CASE WHEN away_team_id = %s THEN 1 END) as away_matches,
            COUNT(CASE WHEN away_team_id = %s AND ftr = 'A' THEN 1 END) as away_wins,
            COALESCE(AVG(CASE WHEN away_team_id = %s THEN ftag END), 0) as avg_away_scored,
            COALESCE(AVG(CASE WHEN away_team_id = %s THEN fthg END), 0) as avg_away_conceded,
            COALESCE(SUM(CASE WHEN away_team_id = %s THEN ftag - fthg END), 0) as away_goal_diff
        FROM matches
        WHERE season = '2025-2026' AND (home_team_id = %s OR away_team_id = %s)
    """, (team_id, team_id, team_id, team_id, team_id, team_id, team_id, team_id, team_id, team_id, team_id, team_id))
    
    row = cursor.fetchone()
    conn.close()
    
    home_matches = row[0] or 0
    home_wins = row[1] or 0
    away_matches = row[5] or 0
    away_wins = row[6] or 0
    total_matches = home_matches + away_matches
    
    total_goals_scored = (row[2] or 0) * home_matches + (row[7] or 0) * away_matches
    total_goals_conceded = (row[3] or 0) * home_matches + (row[8] or 0) * away_matches
    total_goal_diff = (row[4] or 0) + (row[9] or 0)
    
    return jsonify({
        'home_wins': home_wins,
        'away_wins': away_wins,
        'home_win_rate': round(home_wins / home_matches * 100, 1) if home_matches > 0 else 0,
        'away_win_rate': round(away_wins / away_matches * 100, 1) if away_matches > 0 else 0,
        'avg_goals_scored': round(total_goals_scored / total_matches, 2) if total_matches > 0 else 0,
        'avg_goals_conceded': round(total_goals_conceded / total_matches, 2) if total_matches > 0 else 0,
        'goal_diff': total_goal_diff
    })


@app.route('/api/recent_results/<int:team_id>', methods=['GET'])
def get_recent_results(team_id):
    """Получить последние 7 результатов команды"""
    conn = psycopg2.connect(**DB_SETTINGS)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT 
            CASE WHEN home_team_id = %s THEN away_team_id ELSE home_team_id END as opponent_id,
            CASE WHEN home_team_id = %s THEN fthg ELSE ftag END as goals_for,
            CASE WHEN home_team_id = %s THEN ftag ELSE fthg END as goals_against,
            CASE 
                WHEN home_team_id = %s AND ftr = 'H' THEN 'Победа'
                WHEN away_team_id = %s AND ftr = 'A' THEN 'Победа'
                WHEN ftr = 'D' THEN 'Ничья'
                ELSE 'Поражение'
            END as result
        FROM matches
        WHERE (home_team_id = %s OR away_team_id = %s) AND ftr IS NOT NULL
        ORDER BY match_date DESC
        LIMIT 7
    """, (team_id, team_id, team_id, team_id, team_id, team_id, team_id))
    
    results = []
    for row in cursor.fetchall():
        cursor.execute("SELECT team_name FROM teams WHERE team_id = %s", (row[0],))
        opponent_name = cursor.fetchone()[0]
        results.append({
            'opponent': opponent_name,
            'score': f"{row[1]}-{row[2]}",
            'result': row[3]
        })
    conn.close()
    return jsonify(results)


@app.route('/api/recent_matches', methods=['GET'])
def get_recent_matches():
    """Получить последние матчи с прогнозами"""
    limit = request.args.get('limit', 10, type=int)
    league_code = request.args.get('league', None)
    
    conn = psycopg2.connect(**DB_SETTINGS)
    cursor = conn.cursor()
    
    query = """
        SELECT 
            m.match_id,
            m.home_team_id,
            m.away_team_id,
            m.fthg,
            m.ftag,
            m.ftr,
            m.match_date,
            l.league_name,
            l.league_code,
            t1.team_name as home_name,
            t2.team_name as away_name
        FROM matches m
        JOIN leagues l ON m.league_id = l.league_id
        JOIN teams t1 ON m.home_team_id = t1.team_id
        JOIN teams t2 ON m.away_team_id = t2.team_id
        WHERE m.ftr IS NOT NULL
    """
    
    params = []
    if league_code and league_code != 'all':
        query += " AND l.league_code = %s"
        params.append(league_code)
    
    query += " ORDER BY m.match_date DESC LIMIT %s"
    params.append(limit)
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    
    matches = []
    for row in rows:
        match_id, home_id, away_id, fthg, ftag, ftr, match_date, league_name, league_code, home_name, away_name = row
        
        result = predictor.predict(home_id, away_id, show_confidence=False)
        
        actual_result = None
        if ftr == 'H':
            actual_result = 'Победа хозяев'
        elif ftr == 'A':
            actual_result = 'Победа гостей'
        else:
            actual_result = 'Ничья'
        
        matches.append({
            'id': match_id,
            'home_team': home_name,
            'away_team': away_name,
            'score': f"{fthg}-{ftag}",
            'result': actual_result,
            'prediction': result['outcome'] if result else 'Н/Д',
            'date': match_date.strftime('%d.%m.%Y'),
            'league': league_name
        })
    
    conn.close()
    return jsonify(matches)


@app.route('/api/predict', methods=['POST'])
def predict_match():
    """Предсказать матч с объяснением"""
    data = request.json
    home_id = int(data.get('home_id'))
    away_id = int(data.get('away_id'))
    
    result = predictor.predict(home_id, away_id, show_confidence=True)
    
    if not result:
        return jsonify({'error': 'Команды не найдены'}), 404
    
    explanation = []
    try:
        import io
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        predictor.analyze_match(home_id, away_id)
        explanation_text = sys.stdout.getvalue()
        sys.stdout = old_stdout
        
        if "ВЫВОД:" in explanation_text:
            parts = explanation_text.split("ВЫВОД:")
            if len(parts) > 1:
                lines = parts[1].strip().split('\n')
                for line in lines[:5]:
                    line = line.strip()
                    if line and not line.startswith('=') and not line.startswith('-'):
                        explanation.append(line.replace('   ', ''))
    except:
        pass
    
    return jsonify({
        'home_team': result['home'],
        'away_team': result['away'],
        'probabilities': {
            'home_win': round(result['probs']['1'] * 100, 1),
            'draw': round(result['probs']['X'] * 100, 1),
            'away_win': round(result['probs']['2'] * 100, 1)
        },
        'outcome': result['outcome'],
        'total': {
            'prediction': result['total']['pred'],
            'over': round(result['total']['over'] * 100, 1),
            'under': round(result['total']['under'] * 100, 1)
        },
        'confidence': result.get('confidence'),
        'explanation': explanation
    })


@app.route('/api/h2h_stats', methods=['POST'])
def get_h2h_stats():
    """Получить статистику личных встреч между двумя командами"""
    data = request.json
    team1_id = int(data.get('team1_id'))
    team2_id = int(data.get('team2_id'))
    
    conn = psycopg2.connect(**DB_SETTINGS)
    cursor = conn.cursor()
    
    # Получаем имена команд
    cursor.execute("SELECT team_name FROM teams WHERE team_id = %s", (team1_id,))
    team1_name = cursor.fetchone()[0]
    cursor.execute("SELECT team_name FROM teams WHERE team_id = %s", (team2_id,))
    team2_name = cursor.fetchone()[0]
    
    # Получаем все матчи между командами
    cursor.execute("""
        SELECT 
            m.match_date,
            m.home_team_id,
            m.away_team_id,
            m.fthg,
            m.ftag,
            m.ftr,
            t1.team_name as home_name,
            t2.team_name as away_name
        FROM matches m
        JOIN teams t1 ON m.home_team_id = t1.team_id
        JOIN teams t2 ON m.away_team_id = t2.team_id
        WHERE (m.home_team_id = %s AND m.away_team_id = %s)
           OR (m.home_team_id = %s AND m.away_team_id = %s)
        ORDER BY m.match_date DESC
    """, (team1_id, team2_id, team2_id, team1_id))
    
    rows = cursor.fetchall()
    conn.close()
    
    total = len(rows)
    team1_wins = 0
    team2_wins = 0
    draws = 0
    
    recent_matches = []
    
    for row in rows:
        date, home_id, away_id, fthg, ftag, ftr, home_name, away_name = row
        
        # Определяем победителя и считаем победы
        if ftr == 'H':
            winner = home_name
            # Победа хозяев
            if home_name == team1_name:
                team1_wins += 1
            else:
                team2_wins += 1
        elif ftr == 'A':
            winner = away_name
            # Победа гостей
            if away_name == team1_name:
                team1_wins += 1
            else:
                team2_wins += 1
        else:  # 'D'
            winner = 'Ничья'
            draws += 1
        
        # Добавляем в последние 5 матчей
        if len(recent_matches) < 5:
            recent_matches.append({
                'date': date.strftime('%d.%m.%Y'),
                'home_team': home_name,
                'away_team': away_name,
                'score': f"{fthg}-{ftag}",
                'winner': winner
            })
    
    # Проверка: сумма должна равняться total
    if team1_wins + draws + team2_wins != total:
        # Логируем ошибку, но продолжаем
        print(f"WARNING: {team1_wins} + {draws} + {team2_wins} = {team1_wins+draws+team2_wins} != {total}")
    
    return jsonify({
        'total_matches': total,
        'first_team_wins': team1_wins,
        'second_team_wins': team2_wins,
        'draws': draws,
        'first_team_win_rate': round(team1_wins / total * 100, 1) if total > 0 else 0,
        'second_team_win_rate': round(team2_wins / total * 100, 1) if total > 0 else 0,
        'draw_rate': round(draws / total * 100, 1) if total > 0 else 0,
        'recent_matches': recent_matches
    })


@app.route('/api/health', methods=['GET'])
def health_check():
    """Проверка работоспособности API"""
    return jsonify({'status': 'ok', 'accuracy': predictor.best_accuracy})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)